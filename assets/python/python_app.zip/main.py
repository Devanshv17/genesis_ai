# python_app/main.py
import time
import os
import io
import contextlib

INPUT_FILE = "input.txt"
OUTPUT_FILE = "output.txt"

print("Python Code Executor started.")

while True:
    try:
        if os.path.exists(INPUT_FILE):
            print(f"Found {INPUT_FILE}, executing script...")

            with open(INPUT_FILE, "r") as f:
                script_code = f.read()

            # Create a string buffer to capture print statements
            output_buffer = io.StringIO()

            try:
                # Execute the script and redirect stdout to our buffer
                with contextlib.redirect_stdout(output_buffer):
                    exec(script_code)

                # Get the captured output
                answer = output_buffer.getvalue().strip()
                print(f"Script executed. Output: {answer}")

            except Exception as e:
                answer = f"Error executing script: {str(e)}"
                print(f"Error during exec: {e}")

            with open(OUTPUT_FILE, "w") as f:
                f.write(answer)

            os.remove(INPUT_FILE)
            print(f"Finished. Deleted {INPUT_FILE}.")

    except Exception as e:
        print(f"An error occurred in the main loop: {e}")

    time.sleep(0.1)